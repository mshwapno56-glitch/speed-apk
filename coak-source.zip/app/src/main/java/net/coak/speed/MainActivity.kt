package net.coak.speed

import android.annotation.SuppressLint
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(0xFF0A1020.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    val url = request.url
                    if (url.scheme == "tel") {
                        try {
                            startActivity(Intent(Intent.ACTION_DIAL, url))
                        } catch (_: Exception) {
                        }
                        return true
                    }
                    return false
                }
            }
            addJavascriptInterface(Bridge(), "CoakNative")
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                finish()
            }
        })
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    inner class Bridge {

        /** Returns {"conn":"wifi|mobile|ethernet|other|none","sim":"<operator name>"} */
        @JavascriptInterface
        fun getNetInfo(): String {
            val o = JSONObject()
            o.put("conn", connectionType())
            o.put("sim", simName(o.getString("conn")))
            return o.toString()
        }

        @JavascriptInterface
        fun keepScreenOn(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    private fun connectionType(): String {
        return try {
            val cm = getSystemService(ConnectivityManager::class.java)
            val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "none"
            when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
                else -> "other"
            }
        } catch (_: Exception) {
            "other"
        }
    }

    private fun simName(conn: String): String {
        return try {
            var tm = getSystemService(TelephonyManager::class.java) ?: return ""
            // On dual-SIM phones, prefer the SIM that is used for mobile data.
            try {
                val id = SubscriptionManager.getDefaultDataSubscriptionId()
                if (id != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
                    tm = tm.createForSubscriptionId(id)
                }
            } catch (_: Exception) {
            }
            if (tm.simState == TelephonyManager.SIM_STATE_ABSENT) return ""
            val sim = tm.simOperatorName.orEmpty().trim()
            val net = tm.networkOperatorName.orEmpty().trim()
            // On mobile data show the network we are really on (handles roaming); on Wi-Fi show the SIM.
            if (conn == "mobile") net.ifEmpty { sim } else sim.ifEmpty { net }
        } catch (_: Exception) {
            ""
        }
    }
}
